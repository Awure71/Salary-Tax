import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { ArrowLeft, Loader2, CheckCircle } from 'lucide-react';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { generatePDFPayslip } from "@/lib/pdf-generator";

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const CheckoutForm = ({ calculationData }: { calculationData: any }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentSucceeded, setPaymentSucceeded] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}?payment=success`,
        },
        redirect: 'if_required',
      });

      if (error) {
        toast({
          title: "Payment Failed",
          description: error.message,
          variant: "destructive",
        });
      } else {
        setPaymentSucceeded(true);
        
        // Generate and download PDF
        try {
          generatePDFPayslip(calculationData);
          toast({
            title: "Payment Successful!",
            description: "Your PDF payslip has been generated and will download shortly.",
          });
        } catch (pdfError) {
          toast({
            title: "Payment Successful",
            description: "Payment completed successfully. PDF generation failed, please contact support.",
            variant: "destructive",
          });
        }
      }
    } catch (error: any) {
      toast({
        title: "Payment Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  if (paymentSucceeded) {
    return (
      <Card className="max-w-md mx-auto">
        <CardContent className="pt-6 text-center">
          <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Payment Successful!</h2>
          <p className="text-muted-foreground mb-6">
            Your PDF payslip has been generated and should download automatically.
          </p>
          <Button onClick={() => setLocation('/')} className="w-full">
            Return to Calculator
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setLocation('/')}
            className="mr-2 p-1"
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          Complete Payment
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="mb-6">
          <div className="bg-muted/50 p-4 rounded-lg mb-4">
            <div className="flex justify-between mb-2">
              <span>Professional PDF Payslip</span>
              <span className="font-semibold">$1.50</span>
            </div>
            <div className="text-sm text-muted-foreground">
              For salary: {calculationData?.currencySymbol}{calculationData?.grossSalary?.toLocaleString() || '0'}
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <PaymentElement />
          </div>
          
          <Button 
            type="submit"
            className="w-full gradient-bg text-white font-semibold"
            disabled={!stripe || isProcessing}
            data-testid="button-submit-payment"
          >
            {isProcessing ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Processing Payment...
              </>
            ) : (
              'Pay $1.50'
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default function Checkout() {
  const [clientSecret, setClientSecret] = useState("");
  const [calculationData, setCalculationData] = useState<any>(null);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    // Get calculation data from localStorage
    const storedData = localStorage.getItem('salaryCalculation');
    if (!storedData) {
      toast({
        title: "No Calculation Found",
        description: "Please calculate your salary first before proceeding to payment.",
        variant: "destructive",
      });
      setLocation('/');
      return;
    }

    const data = JSON.parse(storedData);
    setCalculationData(data);

    // Create PaymentIntent
    apiRequest("POST", "/api/create-payment-intent", { 
      calculationId: null // We're not storing calculations in this simple version
    })
      .then((res) => res.json())
      .then((data) => {
        setClientSecret(data.clientSecret);
      })
      .catch((error) => {
        toast({
          title: "Payment Setup Failed",
          description: "Unable to initialize payment. Please try again.",
          variant: "destructive",
        });
        setLocation('/');
      });
  }, []);

  if (!clientSecret || !calculationData) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p>Setting up payment...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <Elements stripe={stripePromise} options={{ clientSecret }}>
          <CheckoutForm calculationData={calculationData} />
        </Elements>
      </div>
    </div>
  );
}
