import { useState } from "react";
import { Calculator, Share2, Users, Shield, Smartphone, Calendar } from "lucide-react";
import SalaryCalculator from "@/components/salary-calculator";
import SalaryResults from "@/components/salary-results";
import PaymentModal from "@/components/payment-modal";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export interface CalculationResult {
  countryCode: string;
  currency: string;
  currencySymbol: string;
  grossSalary: number;
  incomeTax: number;
  deductions: Array<{
    id: string;
    name: string;
    amount: number;
    rate: number;
  }>;
  totalDeductions: number;
  netPay: number;
  employmentType: string;
  state?: string;
  taxBandBreakdown: Array<{
    range: string;
    rate: string;
    taxableAmount: number;
    taxAmount: number;
  }>;
}

export default function Home() {
  const [calculationResult, setCalculationResult] = useState<CalculationResult | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);

  const scrollToCalculator = () => {
    document.getElementById('calculator')?.scrollIntoView({ behavior: 'smooth' });
  };

  const shareToTwitter = () => {
    if (!calculationResult) return;
    
    const { grossSalary, netPay, currencySymbol } = calculationResult;
    const text = `I calculated my salary: ${currencySymbol}${grossSalary.toLocaleString()} gross = ${currencySymbol}${netPay.toLocaleString()} take-home. Calculate yours at`;
    const url = window.location.origin;
    
    window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Calculator className="h-8 w-8 text-primary" />
              <span className="text-xl font-bold">SalaryTax</span>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <a href="#calculator" className="text-muted-foreground hover:text-primary transition-colors">Calculator</a>
              <a href="#features" className="text-muted-foreground hover:text-primary transition-colors">Features</a>
              <a href="#pricing" className="text-muted-foreground hover:text-primary transition-colors">Pricing</a>
              <Button onClick={shareToTwitter} className="bg-primary text-primary-foreground">
                <Share2 className="h-4 w-4 mr-2" />
                Share
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-24 pb-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">
            Know Your Exact <span className="gradient-text">Take-Home Pay</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
            Free global salary tax calculator. Calculate income tax, pension, and deductions for any country instantly. Get professional payslips in seconds.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
            <Button onClick={scrollToCalculator} size="lg" className="gradient-bg text-white font-semibold">
              <Calculator className="h-5 w-5 mr-2" />
              Calculate Now - Free
            </Button>
            <Button variant="outline" size="lg">
              See Demo
            </Button>
          </div>
          
          <div className="flex flex-wrap justify-center items-center gap-8 text-sm text-muted-foreground">
            <div className="flex items-center">
              <Users className="h-4 w-4 mr-2 text-primary" />
              <span>Used by 100,000+ workers</span>
            </div>
            <div className="flex items-center">
              <Shield className="h-4 w-4 mr-2 text-primary" />
              <span>100% Secure</span>
            </div>
            <div className="flex items-center">
              <Smartphone className="h-4 w-4 mr-2 text-primary" />
              <span>Mobile Optimized</span>
            </div>
            <div className="flex items-center">
              <Calendar className="h-4 w-4 mr-2 text-primary" />
              <span>2024 Tax Rates</span>
            </div>
          </div>
        </div>
      </section>

      {/* Calculator Section */}
      <section id="calculator" className="py-12 px-4 sm:px-6 lg:px-8 bg-muted/30">
        <div className="max-w-4xl mx-auto">
          <SalaryCalculator onCalculate={setCalculationResult} />
          
          {calculationResult && (
            <SalaryResults 
              result={calculationResult} 
              onDownloadPdf={() => setShowPaymentModal(true)}
            />
          )}
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose SalaryTax?</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              The most accurate and comprehensive salary calculator for workers worldwide
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-3">100% Accurate</h3>
                <p className="text-muted-foreground">Updated with latest tax rates, pension contributions, and statutory deductions for multiple countries</p>
              </CardContent>
            </Card>
            
            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Smartphone className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-3">Mobile Optimized</h3>
                <p className="text-muted-foreground">Perfect for sharing on social media and calculating on-the-go</p>
              </CardContent>
            </Card>
            
            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Calculator className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-3">Professional Payslips</h3>
                <p className="text-muted-foreground">Generate official-looking payslips for loan applications and records</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-muted/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Trusted by Professionals Worldwide</h2>
            
            <div className="grid md:grid-cols-3 gap-8 mb-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">50K+</div>
                <div className="text-muted-foreground">Calculations Made</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">15K+</div>
                <div className="text-muted-foreground">Payslips Downloaded</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">4.9★</div>
                <div className="text-muted-foreground">User Rating</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Simple, Transparent Pricing</h2>
            <p className="text-xl text-muted-foreground">Calculate for free, pay only for premium features</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <h3 className="text-xl font-bold mb-2">Free Calculator</h3>
                <div className="text-3xl font-bold mb-6">Free</div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center text-muted-foreground">
                    <Shield className="h-4 w-4 text-primary mr-3" />
                    Unlimited calculations
                  </li>
                  <li className="flex items-center text-muted-foreground">
                    <Shield className="h-4 w-4 text-primary mr-3" />
                    Basic payslip preview
                  </li>
                  <li className="flex items-center text-muted-foreground">
                    <Shield className="h-4 w-4 text-primary mr-3" />
                    Social sharing
                  </li>
                </ul>
                <Button onClick={scrollToCalculator} variant="outline" className="w-full">
                  Get Started Free
                </Button>
              </CardContent>
            </Card>
            
            <Card className="p-6 hover:shadow-lg transition-shadow border-primary relative">
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <span className="bg-primary text-primary-foreground px-4 py-1 rounded-full text-sm font-semibold">Most Popular</span>
              </div>
              <CardContent className="pt-6">
                <h3 className="text-xl font-bold mb-2">PDF Payslip</h3>
                <div className="text-3xl font-bold mb-6">$1.50</div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center text-muted-foreground">
                    <Shield className="h-4 w-4 text-primary mr-3" />
                    Everything in Free
                  </li>
                  <li className="flex items-center text-muted-foreground">
                    <Shield className="h-4 w-4 text-primary mr-3" />
                    Professional PDF payslip
                  </li>
                  <li className="flex items-center text-muted-foreground">
                    <Shield className="h-4 w-4 text-primary mr-3" />
                    Email delivery
                  </li>
                </ul>
                <Button onClick={() => setShowPaymentModal(true)} className="w-full gradient-bg text-white">
                  Download PDF
                </Button>
              </CardContent>
            </Card>
            
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <h3 className="text-xl font-bold mb-2">HR SaaS</h3>
                <div className="text-3xl font-bold mb-1">$29</div>
                <div className="text-muted-foreground mb-6">/month</div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center text-muted-foreground">
                    <Shield className="h-4 w-4 text-primary mr-3" />
                    Everything in PDF
                  </li>
                  <li className="flex items-center text-muted-foreground">
                    <Shield className="h-4 w-4 text-primary mr-3" />
                    Bulk processing
                  </li>
                  <li className="flex items-center text-muted-foreground">
                    <Shield className="h-4 w-4 text-primary mr-3" />
                    Priority support
                  </li>
                </ul>
                <Button variant="outline" className="w-full">
                  Contact Sales
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Payment Modal */}
      {showPaymentModal && (
        <PaymentModal 
          calculationResult={calculationResult}
          onClose={() => setShowPaymentModal(false)}
        />
      )}
    </div>
  );
}
