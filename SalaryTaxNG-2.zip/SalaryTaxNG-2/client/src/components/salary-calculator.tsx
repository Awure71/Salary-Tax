import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Calculator, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { calculateGlobalTax, getDefaultDeductions } from "@/lib/global-tax-calculator";
import { getAllCountries, getCountry } from "@/lib/countries-config";
import { CalculationResult } from "@/pages/home";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  countryCode: z.string().min(1, "Please select country"),
  grossSalary: z.number().min(1, "Please enter a valid salary"),
  employmentType: z.string().min(1, "Please select employment type"),
  state: z.string().optional(),
  selectedDeductions: z.array(z.string()).default([]),
});

type FormData = z.infer<typeof formSchema>;

interface SalaryCalculatorProps {
  onCalculate: (result: CalculationResult) => void;
}

export default function SalaryCalculator({ onCalculate }: SalaryCalculatorProps) {
  const [isCalculating, setIsCalculating] = useState(false);
  const { toast } = useToast();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      countryCode: "NG",
      grossSalary: 0,
      employmentType: "",
      state: "",
      selectedDeductions: getDefaultDeductions("NG"),
    },
  });
  
  const countries = getAllCountries();
  const watchedCountry = form.watch("countryCode");
  const selectedCountry = getCountry(watchedCountry);

  const onSubmit = async (data: FormData) => {
    setIsCalculating(true);
    
    try {
      // Simulate calculation delay for better UX
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const result = calculateGlobalTax(data);
      onCalculate(result);
      
      // Scroll to results
      setTimeout(() => {
        const resultsElement = document.querySelector('[data-testid="salary-results"]');
        if (resultsElement) {
          resultsElement.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
      
      toast({
        title: "Calculation Complete",
        description: "Your salary breakdown has been calculated successfully.",
      });
    } catch (error) {
      toast({
        title: "Calculation Error",
        description: "There was an error calculating your salary. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsCalculating(false);
    }
  };

  const setQuickAmount = (amount: number) => {
    form.setValue("grossSalary", amount);
  };

  return (
    <Card className="w-full">
      <CardHeader className="gradient-bg text-white">
        <CardTitle className="text-2xl flex items-center">
          <Calculator className="h-6 w-6 mr-2" />
          Global Salary Calculator
        </CardTitle>
        <p className="opacity-90">Enter your gross salary to see your exact take-home pay for any country</p>
      </CardHeader>
      
      <CardContent className="p-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6" data-testid="salary-form">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Country Selection */}
              <FormField
                control={form.control}
                name="countryCode"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Country</FormLabel>
                    <Select onValueChange={(value) => {
                      field.onChange(value);
                      // Reset deductions to country defaults
                      form.setValue("selectedDeductions", getDefaultDeductions(value));
                      form.setValue("state", "");
                    }} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-country">
                          <SelectValue placeholder="Select country" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {countries.map((country) => (
                          <SelectItem key={country.code} value={country.code}>
                            {country.name} ({country.currency.code})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
              
              {/* Gross Salary */}
              <FormField
                control={form.control}
                name="grossSalary"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Gross Monthly Salary ({selectedCountry?.currency.symbol || ''})</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <span className="absolute left-3 top-3 text-muted-foreground">{selectedCountry?.currency.symbol || ''}</span>
                        <Input
                          {...field}
                          type="number"
                          placeholder="0"
                          className="pl-8"
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          data-testid="input-gross-salary"
                        />
                      </div>
                    </FormControl>
                  </FormItem>
                )}
              />
              
              {/* Employment Type */}
              <FormField
                control={form.control}
                name="employmentType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Employment Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-employment-type">
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="full-time">Full-time Employee</SelectItem>
                        <SelectItem value="part-time">Part-time Employee</SelectItem>
                        <SelectItem value="contract">Contract Worker</SelectItem>
                        <SelectItem value="freelance">Freelance</SelectItem>
                        <SelectItem value="self-employed">Self-employed</SelectItem>
                        <SelectItem value="intern">Intern</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
              
              {/* State/Region - Only show if country has states */}
              {selectedCountry?.states && (
                <FormField
                  control={form.control}
                  name="state"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>State/Region</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || ""}>
                        <FormControl>
                          <SelectTrigger data-testid="select-state">
                            <SelectValue placeholder="Select state" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {selectedCountry.states?.map((state) => (
                            <SelectItem key={state} value={state.toLowerCase().replace(/[()\s]/g, '-')}>
                              {state}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormItem>
                  )}
                />
              )}
            </div>
            
            {/* Deduction Options */}
            {selectedCountry && selectedCountry.deductions.length > 0 && (
              <Card className="bg-muted/50">
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-3">Deduction Options</h3>
                  <div className="space-y-3">
                    <FormField
                      control={form.control}
                      name="selectedDeductions"
                      render={() => (
                        <FormItem>
                          {selectedCountry.deductions.map((deduction) => (
                            <FormField
                              key={deduction.id}
                              control={form.control}
                              name="selectedDeductions"
                              render={({ field }) => {
                                return (
                                  <FormItem
                                    key={deduction.id}
                                    className="flex flex-row items-center space-x-3 space-y-0"
                                  >
                                    <FormControl>
                                      <Checkbox
                                        checked={field.value?.includes(deduction.id)}
                                        onCheckedChange={(checked) => {
                                          return checked
                                            ? field.onChange([...field.value, deduction.id])
                                            : field.onChange(
                                                field.value?.filter(
                                                  (value) => value !== deduction.id
                                                )
                                              );
                                        }}
                                        data-testid={`checkbox-${deduction.id}`}
                                      />
                                    </FormControl>
                                    <FormLabel className="text-sm font-normal">
                                      {deduction.name} ({(deduction.rate * 100).toFixed(1)}%)
                                      <div className="text-xs text-muted-foreground">
                                        {deduction.description}
                                      </div>
                                    </FormLabel>
                                  </FormItem>
                                );
                              }}
                            />
                          ))}
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>
            )}
            
            {/* Calculate Button */}
            <Button 
              type="submit" 
              className="w-full gradient-bg text-white font-semibold py-4"
              disabled={isCalculating}
              data-testid="button-calculate"
            >
              {isCalculating ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Calculating...
                </>
              ) : (
                <>
                  <Calculator className="h-4 w-4 mr-2" />
                  Calculate My Take-Home Pay
                </>
              )}
            </Button>
            
            {/* Quick Examples */}
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-3">Quick examples:</p>
              <div className="flex flex-wrap justify-center gap-2">
                <Button 
                  type="button" 
                  variant="secondary" 
                  size="sm"
                  onClick={() => setQuickAmount(1500)}
                  data-testid="button-quick-1500"
                >
                  {selectedCountry?.currency.symbol}1,500
                </Button>
                <Button 
                  type="button" 
                  variant="secondary" 
                  size="sm"
                  onClick={() => setQuickAmount(3000)}
                  data-testid="button-quick-3000"
                >
                  {selectedCountry?.currency.symbol}3,000
                </Button>
                <Button 
                  type="button" 
                  variant="secondary" 
                  size="sm"
                  onClick={() => setQuickAmount(5000)}
                  data-testid="button-quick-5000"
                >
                  {selectedCountry?.currency.symbol}5,000
                </Button>
                <Button 
                  type="button" 
                  variant="secondary" 
                  size="sm"
                  onClick={() => setQuickAmount(10000)}
                  data-testid="button-quick-10000"
                >
                  {selectedCountry?.currency.symbol}10,000
                </Button>
              </div>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
