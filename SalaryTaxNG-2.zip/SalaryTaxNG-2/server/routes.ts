import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import { storage } from "./storage";
import { insertCalculationSchema, insertPaymentSchema } from "@shared/schema";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-08-27.basil",
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Create salary calculation
  app.post("/api/calculations", async (req, res) => {
    try {
      const calculationData = insertCalculationSchema.parse(req.body);
      const calculation = await storage.createCalculation(calculationData);
      res.json(calculation);
    } catch (error: any) {
      res.status(400).json({ message: "Invalid calculation data: " + error.message });
    }
  });

  // Get calculation by ID
  app.get("/api/calculations/:id", async (req, res) => {
    try {
      const calculation = await storage.getCalculation(req.params.id);
      if (!calculation) {
        return res.status(404).json({ message: "Calculation not found" });
      }
      res.json(calculation);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching calculation: " + error.message });
    }
  });

  // Create payment intent for PDF payslip
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      const { calculationId } = req.body;
      const amount = 150; // $1.50 USD for PDF payslip
      
      const paymentIntent = await stripe.paymentIntents.create({
        amount: amount, // Amount in cents
        currency: "usd",
        metadata: {
          calculationId: calculationId || "",
          type: "pdf_payslip"
        },
      });

      // Store payment record
      await storage.createPayment({
        calculationId,
        stripePaymentIntentId: paymentIntent.id,
        amount: (amount / 100).toString(),
        currency: "usd",
        status: "pending",
        pdfGenerated: false,
      });

      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  // Webhook for Stripe payment confirmation
  app.post("/api/webhook/stripe", async (req, res) => {
    try {
      const sig = req.headers['stripe-signature'];
      let event;

      try {
        event = stripe.webhooks.constructEvent(req.body, sig!, process.env.STRIPE_WEBHOOK_SECRET!);
      } catch (err: any) {
        return res.status(400).send(`Webhook signature verification failed: ${err.message}`);
      }

      if (event.type === 'payment_intent.succeeded') {
        const paymentIntent = event.data.object as Stripe.PaymentIntent;
        
        // Find and update payment record
        const payments = await storage.getPayment(paymentIntent.id);
        if (payments) {
          await storage.updatePaymentStatus(payments.id, "succeeded");
        }
      }

      res.json({ received: true });
    } catch (error: any) {
      res.status(500).json({ message: "Webhook error: " + error.message });
    }
  });

  // Generate PDF payslip (after successful payment)
  app.post("/api/generate-pdf", async (req, res) => {
    try {
      const { paymentIntentId } = req.body;
      
      // This would typically generate and email the PDF
      // For now, we'll just return success
      res.json({ 
        success: true, 
        message: "PDF payslip has been generated and sent to your email" 
      });
    } catch (error: any) {
      res.status(500).json({ message: "Error generating PDF: " + error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
