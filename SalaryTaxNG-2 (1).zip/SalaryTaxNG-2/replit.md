# SalaryTax - Global Salary Tax Calculator

## Overview

SalaryTax is a web application that calculates salary taxes and deductions for multiple countries, providing users with accurate breakdown of their take-home pay. The application allows users to input their gross salary and various employment details to calculate income tax, pension contributions, and other deductions according to their country's tax laws. Users can also purchase PDF payslips for their calculations through Stripe payment integration.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

- **November 2025**: Google AdSense compliance and content expansion
  - Added ownership verification meta tag for salarytax.org (ca-pub-7886397222869926)
  - Created comprehensive blog system with 5 detailed articles (500+ words each):
    * Understanding Income Tax Brackets
    * Pension Contributions Explained
    * Tax Deductions vs Credits
    * How to Calculate Your Take-Home Pay
    * Self-Employment Tax Guide
  - Created essential pages: About Us, FAQ, Contact, Tax Guides
  - Added navigation menu linking to all content pages
  - Implemented conditional AdSense loading (only on content-rich pages: blog, guides, about, FAQ, contact)
  - Blog posts include proper CSS styling for improved readability
  - Excluded AdSense from transactional pages (checkout, calculator) to avoid "screens without publisher content" policy violations
  - Full globalization and monetization complete: 3-tier paid pricing model (Basic $0.50, PDF $1.50, HR SaaS $29/month) with live Stripe integration

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript for type safety and modern development
- **Build Tool**: Vite for fast development and optimized production builds
- **UI Framework**: shadcn/ui components built on Radix UI primitives for accessible, customizable components
- **Styling**: Tailwind CSS with CSS variables for theming and responsive design
- **State Management**: React Query (TanStack Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation for type-safe form handling

### Backend Architecture
- **Runtime**: Node.js with Express.js framework for RESTful API endpoints
- **Language**: TypeScript with ES modules for modern JavaScript features
- **Database ORM**: Drizzle ORM with PostgreSQL dialect for type-safe database interactions
- **Database**: Neon serverless PostgreSQL for scalable cloud database hosting
- **Session Management**: PostgreSQL-based sessions using connect-pg-simple
- **Build Process**: ESBuild for fast server-side bundling

### Data Storage Solutions
- **Primary Database**: PostgreSQL via Neon serverless platform
- **Schema Management**: Drizzle Kit for database migrations and schema management
- **In-Memory Storage**: Fallback MemStorage class for development/testing
- **Database Tables**:
  - Users: Authentication and Stripe customer data
  - Calculations: Salary calculation results and metadata
  - Payments: Payment tracking and PDF generation status

### Authentication and Authorization
- **Strategy**: Session-based authentication using PostgreSQL sessions
- **User Management**: Simple username/password system with optional email
- **Session Storage**: Database-backed sessions for scalability and persistence

### External Service Integrations
- **Payment Processing**: Stripe integration for PDF payslip purchases
  - Payment intents for secure transactions
  - Multi-currency support for global payments
  - Webhook handling for payment status updates
- **PDF Generation**: jsPDF library for client-side PDF payslip creation
- **Development Tools**: Replit-specific plugins for enhanced development experience

### Progressive Web App (PWA) Features
- **Installability**: Full PWA support with web app manifest for Android and iOS devices
- **App Icon**: SVG-based adaptive icon with green theme (#16a34a) and dollar sign ($) symbol
- **Service Worker**: Offline functionality with caching strategy for improved performance
- **Manifest Configuration**: 
  - Standalone display mode for native app-like experience
  - Portrait-primary orientation optimized for mobile use
  - App shortcuts for quick access to calculator functionality
- **Meta Tags**: Complete set of mobile and PWA meta tags including theme color and Apple touch icons

### Key Design Decisions
- **Monorepo Structure**: Shared schema and types between client/server for consistency
- **Type Safety**: Full TypeScript coverage with Zod for runtime validation
- **Responsive Design**: Mobile-first approach with Tailwind CSS breakpoints
- **Payment Flow**: Secure two-step process with payment intent creation and confirmation
- **Tax Calculation**: Client-side calculation with country-specific tax bands and deduction rules
- **Error Handling**: Comprehensive error boundaries and user feedback via toast notifications
- **PWA Implementation**: Service worker registration on app load with automatic caching for offline support

## External Dependencies

- **Database**: Neon serverless PostgreSQL for production data storage
- **Payment Gateway**: Stripe for secure payment processing and subscription management
- **UI Components**: Radix UI primitives for accessible component foundation
- **Development Platform**: Replit for hosting and development environment
- **Font Services**: Google Fonts for typography (Inter, DM Sans, Fira Code, Geist Mono)
- **Build Tools**: Vite ecosystem for frontend tooling and development server