import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { AdSenseScript } from "@/components/adsense";

export default function FAQ() {
  return (
    <div className="min-h-screen bg-background">
      <AdSenseScript />
      {/* Header */}
      <header className="border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <a className="text-2xl font-bold gradient-text" data-testid="link-home">SalaryTax</a>
            </Link>
            <nav className="flex gap-6">
              <Link href="/">
                <a className="hover:text-primary transition-colors" data-testid="link-calculator">Calculator</a>
              </Link>
              <Link href="/blog">
                <a className="hover:text-primary transition-colors" data-testid="link-blog">Blog</a>
              </Link>
              <Link href="/about">
                <a className="hover:text-primary transition-colors" data-testid="link-about">About</a>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="bg-gradient-to-br from-primary/10 to-primary/5 py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Frequently Asked Questions</h1>
          <p className="text-xl text-muted-foreground">
            Everything you need to know about SalaryTax and salary calculations
          </p>
        </div>
      </section>

      {/* FAQ Content */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            <AccordionItem value="item-1" className="border rounded-lg px-6">
              <AccordionTrigger className="text-left">
                How accurate are SalaryTax calculations?
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                <p className="mb-3">
                  SalaryTax maintains a 99.9% accuracy rate by partnering with tax professionals in each country we support. Our calculation engine is updated within 24 hours of any tax law changes to ensure you always receive current information.
                </p>
                <p className="mb-3">
                  We account for progressive tax brackets, regional tax variations, pension contributions, social security, health insurance, and dozens of other factors that impact your take-home pay. However, individual circumstances can vary, and we recommend consulting a tax professional for complex situations.
                </p>
                <p>
                  Our calculations are suitable for general planning, job offer evaluations, and budgeting purposes. For official tax filing, please consult with a licensed tax advisor in your jurisdiction.
                </p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-2" className="border rounded-lg px-6">
              <AccordionTrigger className="text-left">
                Which countries do you support?
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                <p className="mb-3">
                  SalaryTax currently supports 25+ countries including the United States, United Kingdom, Canada, Germany, France, Australia, and many others. Each country has localized tax calculations that account for federal, state/provincial, and local taxes where applicable.
                </p>
                <p className="mb-3">
                  We're continuously expanding our coverage. If your country isn't currently supported, please contact us—we prioritize new countries based on user demand.
                </p>
                <p>
                  Each country's calculator includes specific features like regional tax variations (e.g., state taxes in the US, council taxes in the UK) and country-specific deductions (pension schemes, health insurance, etc.).
                </p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-3" className="border rounded-lg px-6">
              <AccordionTrigger className="text-left">
                Do you store my salary information?
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                <p className="mb-3">
                  No. Your salary calculations are processed in real-time on your device and are never stored on our servers unless you explicitly choose to save a calculation or purchase a PDF payslip.
                </p>
                <p className="mb-3">
                  If you do save a calculation or purchase a PDF, we store only the information necessary to provide that service, and all data is encrypted both in transit and at rest. We comply with GDPR, CCPA, and other international privacy regulations.
                </p>
                <p>
                  You can request deletion of any stored data at any time by contacting our support team. We take your privacy seriously and will never sell or share your personal information with third parties.
                </p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-4" className="border rounded-lg px-6">
              <AccordionTrigger className="text-left">
                What's included in the PDF Payslip?
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                <p className="mb-3">
                  Our Professional PDF Payslip includes a comprehensive breakdown of your salary calculation formatted for professional use. It includes:
                </p>
                <ul className="list-disc list-inside space-y-2 mb-3">
                  <li>Gross salary and pay period details</li>
                  <li>Detailed tax breakdown (federal, state/provincial, local)</li>
                  <li>Pension/retirement contributions</li>
                  <li>Social security and health insurance deductions</li>
                  <li>Net take-home pay calculation</li>
                  <li>Year-to-date projections</li>
                  <li>Professional formatting suitable for loan applications</li>
                </ul>
                <p>
                  The PDF is delivered instantly to your email and can be customized with your employer information. It's accepted by most financial institutions for income verification purposes.
                </p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-5" className="border rounded-lg px-6">
              <AccordionTrigger className="text-left">
                Can I use this for multiple employees (HR purposes)?
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                <p className="mb-3">
                  Yes! Our HR SaaS plan is designed specifically for businesses processing payroll for multiple employees. It includes:
                </p>
                <ul className="list-disc list-inside space-y-2 mb-3">
                  <li>Bulk payslip processing (upload CSV files)</li>
                  <li>Multi-country support for international teams</li>
                  <li>Customizable company branding on payslips</li>
                  <li>Priority support with dedicated account manager</li>
                  <li>Advanced reporting and analytics</li>
                  <li>API access for integration with your systems</li>
                </ul>
                <p>
                  For enterprise needs (100+ employees), we offer custom solutions. Contact our sales team to discuss your requirements and get a tailored quote.
                </p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-6" className="border rounded-lg px-6">
              <AccordionTrigger className="text-left">
                How do tax brackets work?
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                <p className="mb-3">
                  Tax brackets divide your income into portions, each taxed at a different rate. This is called progressive taxation. Many people misunderstand how this works—only the income within each bracket is taxed at that bracket's rate, not your entire income.
                </p>
                <p className="mb-3">
                  For example, if you earn $75,000 and the brackets are 10% up to $10,000, 20% from $10,001-$40,000, and 30% above $40,000:
                </p>
                <ul className="list-disc list-inside space-y-2 mb-3">
                  <li>First $10,000 taxed at 10% = $1,000</li>
                  <li>Next $30,000 taxed at 20% = $6,000</li>
                  <li>Remaining $35,000 taxed at 30% = $10,500</li>
                  <li>Total tax = $17,500 (effective rate: 23.3%)</li>
                </ul>
                <p>
                  Your effective tax rate (actual percentage paid) is almost always lower than your marginal rate (highest bracket). Read our blog post "Understanding Income Tax Brackets" for a deeper dive.
                </p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-7" className="border rounded-lg px-6">
              <AccordionTrigger className="text-left">
                What payment methods do you accept?
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                <p className="mb-3">
                  We accept all major credit and debit cards (Visa, Mastercard, American Express, Discover) through our secure payment processor, Stripe. We also support digital wallets including Apple Pay, Google Pay, and various local payment methods depending on your country.
                </p>
                <p className="mb-3">
                  All transactions are encrypted and PCI-compliant. We never store your payment information on our servers—all sensitive data is handled exclusively by Stripe's secure infrastructure.
                </p>
                <p>
                  For HR SaaS subscriptions, we offer invoicing options for businesses that prefer to pay via bank transfer or purchase order.
                </p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-8" className="border rounded-lg px-6">
              <AccordionTrigger className="text-left">
                Can I get a refund?
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                <p className="mb-3">
                  We offer a 30-day money-back guarantee on all purchases. If you're not satisfied with your PDF payslip or SaaS subscription for any reason, contact us within 30 days for a full refund—no questions asked.
                </p>
                <p className="mb-3">
                  For the Basic Payslip ($0.50), we typically don't process refunds due to the minimal cost, but we're happy to address any concerns or issues you encounter.
                </p>
                <p>
                  To request a refund, simply email our support team with your order details. Most refunds are processed within 3-5 business days.
                </p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-9" className="border rounded-lg px-6">
              <AccordionTrigger className="text-left">
                How often are tax rates updated?
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                <p className="mb-3">
                  We monitor tax legislation in all supported countries continuously. When a tax law changes, we update our calculation engine within 24 hours. This ensures you always receive accurate calculations based on current regulations.
                </p>
                <p className="mb-3">
                  Major tax changes typically occur on January 1st or at the start of the fiscal year, but mid-year adjustments can happen. Our system automatically applies the correct tax rates based on the calculation date you specify.
                </p>
                <p>
                  We also maintain historical tax rates, so you can calculate what your take-home pay would have been in previous years for comparison purposes.
                </p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-10" className="border rounded-lg px-6">
              <AccordionTrigger className="text-left">
                Do you offer support for freelancers and self-employed individuals?
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                <p className="mb-3">
                  Yes! While our primary calculator is designed for employed individuals, we're developing a specialized self-employment calculator that accounts for:
                </p>
                <ul className="list-disc list-inside space-y-2 mb-3">
                  <li>Self-employment taxes (additional Medicare/Social Security)</li>
                  <li>Quarterly estimated tax payments</li>
                  <li>Business expense deductions</li>
                  <li>Home office deductions</li>
                  <li>Retirement contributions (SEP IRA, Solo 401(k))</li>
                </ul>
                <p className="mb-3">
                  This feature is currently in beta. If you're interested in early access, please sign up for our newsletter or contact our support team.
                </p>
                <p>
                  In the meantime, our blog has extensive resources on self-employment taxes—check out "Self-Employment Tax: What Freelancers Need to Know" for detailed guidance.
                </p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-11" className="border rounded-lg px-6">
              <AccordionTrigger className="text-left">
                Can I compare salaries across different countries?
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                <p className="mb-3">
                  Absolutely! One of SalaryTax's most powerful features is the ability to compare take-home pay across different countries. This is especially useful for professionals considering international job opportunities.
                </p>
                <p className="mb-3">
                  Simply calculate your salary in multiple countries and compare the results. Our calculator accounts for:
                </p>
                <ul className="list-disc list-inside space-y-2 mb-3">
                  <li>Currency conversion (real-time exchange rates)</li>
                  <li>Cost of living adjustments</li>
                  <li>Different tax systems and rates</li>
                  <li>Social benefits and pension contributions</li>
                  <li>Healthcare costs (where applicable)</li>
                </ul>
                <p>
                  This helps you make apples-to-apples comparisons when evaluating job offers from different countries.
                </p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-12" className="border rounded-lg px-6">
              <AccordionTrigger className="text-left">
                How do I contact customer support?
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                <p className="mb-3">
                  We offer multiple support channels to ensure you get help when you need it:
                </p>
                <ul className="list-disc list-inside space-y-2 mb-3">
                  <li><strong>Email:</strong> support@salarytax.org (response within 24 hours)</li>
                  <li><strong>Live chat:</strong> Available on our website during business hours</li>
                  <li><strong>Help center:</strong> Comprehensive guides and tutorials</li>
                  <li><strong>FAQ:</strong> Quick answers to common questions</li>
                </ul>
                <p className="mb-3">
                  HR SaaS subscribers receive priority support with dedicated account managers and faster response times.
                </p>
                <p>
                  For urgent technical issues, our team monitors support channels 24/7. We typically respond to critical issues within 2 hours.
                </p>
              </AccordionContent>
            </AccordionItem>
          </Accordion>

          {/* CTA */}
          <div className="mt-16 bg-muted/50 rounded-lg p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Still have questions?</h2>
            <p className="text-muted-foreground mb-6">
              Our support team is here to help. Get in touch and we'll respond within 24 hours.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/contact">
                <Button className="gradient-bg text-white" data-testid="button-contact">
                  Contact Support
                </Button>
              </Link>
              <Link href="/">
                <Button variant="outline" data-testid="button-calculator">
                  Try Calculator
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
