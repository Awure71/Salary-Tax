import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, Calendar, Clock } from "lucide-react";
import { AdSenseScript } from "@/components/adsense";

interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  date: string;
  readTime: string;
  slug: string;
}

const blogPosts: BlogPost[] = [
  {
    id: "1",
    title: "Understanding Income Tax Brackets: A Comprehensive Guide for 2025",
    excerpt: "Learn how progressive tax systems work across different countries and how to calculate your effective tax rate for better financial planning.",
    date: "January 15, 2025",
    readTime: "8 min read",
    slug: "understanding-income-tax-brackets-2025"
  },
  {
    id: "2",
    title: "Pension Contributions Explained: Maximizing Your Retirement Savings",
    excerpt: "Discover how pension contributions work globally, including employer matching programs, tax benefits, and strategies to maximize your retirement fund.",
    date: "January 10, 2025",
    readTime: "10 min read",
    slug: "pension-contributions-explained"
  },
  {
    id: "3",
    title: "Tax Deductions vs Tax Credits: What's the Difference?",
    excerpt: "Understanding the difference between tax deductions and credits can save you thousands. Learn which benefits apply to your situation.",
    date: "January 5, 2025",
    readTime: "6 min read",
    slug: "tax-deductions-vs-credits"
  },
  {
    id: "4",
    title: "How to Calculate Your Take-Home Pay: A Step-by-Step Guide",
    excerpt: "Master the art of calculating your net salary by understanding gross pay, deductions, taxes, and other withholdings that affect your paycheck.",
    date: "December 28, 2024",
    readTime: "7 min read",
    slug: "calculate-take-home-pay-guide"
  },
  {
    id: "5",
    title: "Self-Employment Tax: What Freelancers Need to Know",
    excerpt: "Navigate the complexities of self-employment taxes, quarterly payments, allowable deductions, and how to avoid common mistakes.",
    date: "December 20, 2024",
    readTime: "9 min read",
    slug: "self-employment-tax-guide"
  }
];

export default function Blog() {
  return (
    <div className="min-h-screen bg-background">
      <AdSenseScript />
      {/* Header */}
      <header className="border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <a className="text-2xl font-bold gradient-text" data-testid="link-home">SalaryTax</a>
            </Link>
            <nav className="flex gap-6">
              <Link href="/">
                <a className="hover:text-primary transition-colors" data-testid="link-calculator">Calculator</a>
              </Link>
              <Link href="/blog">
                <a className="text-primary font-semibold" data-testid="link-blog">Blog</a>
              </Link>
              <Link href="/about">
                <a className="hover:text-primary transition-colors" data-testid="link-about">About</a>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 to-primary/5 py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Tax & Salary Insights</h1>
          <p className="text-xl text-muted-foreground">
            Expert guides and resources to help you understand your salary, taxes, and financial planning
          </p>
        </div>
      </section>

      {/* Blog Posts */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post) => (
              <Card key={post.id} className="hover:shadow-lg transition-shadow" data-testid={`card-blog-${post.id}`}>
                <CardHeader>
                  <CardTitle className="text-xl mb-2">{post.title}</CardTitle>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      {post.date}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {post.readTime}
                    </span>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">{post.excerpt}</p>
                  <Link href={`/blog/${post.slug}`}>
                    <Button variant="ghost" className="p-0 h-auto font-semibold text-primary" data-testid={`button-read-${post.id}`}>
                      Read More <ArrowRight className="h-4 w-4 ml-2" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-muted/30 py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Calculate Your Take-Home Pay?</h2>
          <p className="text-xl text-muted-foreground mb-8">
            Use our free salary calculator to get accurate tax breakdowns instantly
          </p>
          <Link href="/">
            <Button className="gradient-bg text-white" size="lg" data-testid="button-try-calculator">
              Try Calculator Now
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
