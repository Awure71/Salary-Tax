import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, Users, Globe, TrendingUp, Award, Heart } from "lucide-react";
import { AdSenseScript } from "@/components/adsense";

export default function About() {
  return (
    <div className="min-h-screen bg-background">
      <AdSenseScript />
      {/* Header */}
      <header className="border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <a className="text-2xl font-bold gradient-text" data-testid="link-home">SalaryTax</a>
            </Link>
            <nav className="flex gap-6">
              <Link href="/">
                <a className="hover:text-primary transition-colors" data-testid="link-calculator">Calculator</a>
              </Link>
              <Link href="/blog">
                <a className="hover:text-primary transition-colors" data-testid="link-blog">Blog</a>
              </Link>
              <Link href="/about">
                <a className="text-primary font-semibold" data-testid="link-about">About</a>
              </Link>
              <Link href="/contact">
                <a className="hover:text-primary transition-colors" data-testid="link-contact">Contact</a>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 to-primary/5 py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">About SalaryTax</h1>
          <p className="text-xl md:text-2xl text-muted-foreground">
            Empowering professionals worldwide with accurate salary and tax calculations since 2024
          </p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Our Mission</h2>
              <p className="text-lg text-muted-foreground mb-4">
                At SalaryTax, we believe financial transparency should be accessible to everyone. Understanding your salary, taxes, and deductions shouldn't require a degree in accounting or hours of research.
              </p>
              <p className="text-lg text-muted-foreground mb-4">
                We've built a platform that provides instant, accurate salary calculations for professionals around the world, helping you make informed career and financial decisions with confidence.
              </p>
              <p className="text-lg text-muted-foreground">
                Whether you're evaluating a job offer, planning your budget, or simply curious about your take-home pay, SalaryTax delivers the clarity you need in seconds.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-6">
              <Card className="text-center p-6">
                <CardContent className="pt-6">
                  <Users className="h-12 w-12 mx-auto mb-3 text-primary" />
                  <div className="text-3xl font-bold mb-2">50K+</div>
                  <div className="text-sm text-muted-foreground">Users Worldwide</div>
                </CardContent>
              </Card>
              <Card className="text-center p-6">
                <CardContent className="pt-6">
                  <Globe className="h-12 w-12 mx-auto mb-3 text-primary" />
                  <div className="text-3xl font-bold mb-2">25+</div>
                  <div className="text-sm text-muted-foreground">Countries Supported</div>
                </CardContent>
              </Card>
              <Card className="text-center p-6">
                <CardContent className="pt-6">
                  <TrendingUp className="h-12 w-12 mx-auto mb-3 text-primary" />
                  <div className="text-3xl font-bold mb-2">99.9%</div>
                  <div className="text-sm text-muted-foreground">Accuracy Rate</div>
                </CardContent>
              </Card>
              <Card className="text-center p-6">
                <CardContent className="pt-6">
                  <Award className="h-12 w-12 mx-auto mb-3 text-primary" />
                  <div className="text-3xl font-bold mb-2">4.9★</div>
                  <div className="text-sm text-muted-foreground">User Rating</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="bg-muted/30 py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Our Core Values</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardContent className="p-6">
                <Shield className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-bold mb-3">Accuracy & Trust</h3>
                <p className="text-muted-foreground">
                  We maintain the highest standards of accuracy by continuously updating our tax calculations to reflect the latest regulations in every country we support. Your financial decisions deserve reliable information.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <Globe className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-bold mb-3">Global Accessibility</h3>
                <p className="text-muted-foreground">
                  Tax systems vary dramatically worldwide. We're committed to providing localized, culturally-aware salary calculations that respect the nuances of each country's tax legislation and employment practices.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <Heart className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-xl font-bold mb-3">User-Centric Design</h3>
                <p className="text-muted-foreground">
                  Complex tax calculations shouldn't require complex interfaces. We've designed every feature with simplicity in mind, ensuring anyone can understand their salary breakdown within minutes.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center">Our Story</h2>
          <div className="prose prose-lg max-w-none text-muted-foreground">
            <p className="mb-4">
              SalaryTax was founded in 2024 by a team of financial technology enthusiasts who experienced firsthand the frustration of understanding take-home pay across different countries. After relocating internationally for work, our founders spent countless hours trying to calculate accurate net salaries, only to find existing tools were either inaccurate, outdated, or limited to specific regions.
            </p>
            <p className="mb-4">
              We realized that in an increasingly global workforce, professionals needed a single, reliable platform that could handle the complexity of international tax systems. That realization sparked the creation of SalaryTax—a comprehensive salary calculator built for the modern, mobile workforce.
            </p>
            <p className="mb-4">
              What started as a simple calculator for a handful of countries has grown into a sophisticated platform supporting 25+ nations, with features ranging from basic salary calculations to professional PDF payslips suitable for loan applications and official documentation.
            </p>
            <p>
              Today, we serve over 50,000 users monthly—from job seekers comparing offers across countries, to HR professionals processing international payroll, to individuals simply wanting to understand where their money goes each month. Our commitment remains unchanged: providing transparent, accurate, and accessible financial information to everyone, everywhere.
            </p>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="bg-muted/30 py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-8">Built by Experts</h2>
          <p className="text-center text-lg text-muted-foreground max-w-3xl mx-auto mb-12">
            Our team combines expertise in tax law, software engineering, and user experience design to create the most accurate and user-friendly salary calculator available. We partner with tax professionals in each country we support to ensure our calculations reflect current regulations.
          </p>
          
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-5xl font-bold text-primary mb-2">15+</div>
              <div className="text-muted-foreground">Tax Law Consultants</div>
            </div>
            <div>
              <div className="text-5xl font-bold text-primary mb-2">8</div>
              <div className="text-muted-foreground">Software Engineers</div>
            </div>
            <div>
              <div className="text-5xl font-bold text-primary mb-2">24/7</div>
              <div className="text-muted-foreground">Customer Support</div>
            </div>
          </div>
        </div>
      </section>

      {/* Technology Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center">Technology & Security</h2>
          <div className="space-y-6 text-muted-foreground">
            <div>
              <h3 className="text-xl font-bold text-foreground mb-3">Cutting-Edge Calculations</h3>
              <p>
                Our calculation engine processes millions of data points to deliver results in milliseconds. We use advanced algorithms that account for progressive tax brackets, regional variations, pension contributions, social security, and dozens of other factors that impact your final take-home pay.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-bold text-foreground mb-3">Privacy First</h3>
              <p>
                We take your privacy seriously. Your salary calculations are processed in real-time and never stored on our servers unless you explicitly choose to save them. We use industry-standard encryption for all data transmission and comply with GDPR, CCPA, and other international privacy regulations.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-bold text-foreground mb-3">Regular Updates</h3>
              <p>
                Tax laws change frequently. Our team monitors legislative updates in all supported countries and updates our calculation algorithms within 24 hours of any regulatory changes. This ensures you always receive current, accurate information based on the latest tax codes.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-bold text-foreground mb-3">Open to Feedback</h3>
              <p>
                We continuously improve based on user feedback. If you notice a discrepancy or have suggestions for new features, our team reviews every submission. Many of our most popular features—including the PDF payslip generator and multi-country comparison tool—came directly from user requests.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-br from-primary/10 to-primary/5 py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Calculate Your Salary?</h2>
          <p className="text-xl text-muted-foreground mb-8">
            Join thousands of professionals who trust SalaryTax for accurate salary calculations
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/">
              <Button size="lg" className="gradient-bg text-white" data-testid="button-calculator">
                Try Calculator Now
              </Button>
            </Link>
            <Link href="/contact">
              <Button size="lg" variant="outline" data-testid="button-contact">
                Contact Us
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
