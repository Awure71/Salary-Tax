import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Mail, MessageSquare, Clock, MapPin } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { AdSenseScript } from "@/components/adsense";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Message Sent!",
      description: "We'll get back to you within 24 hours.",
    });
    setFormData({ name: "", email: "", subject: "", message: "" });
  };

  return (
    <div className="min-h-screen bg-background">
      <AdSenseScript />
      {/* Header */}
      <header className="border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <a className="text-2xl font-bold gradient-text" data-testid="link-home">SalaryTax</a>
            </Link>
            <nav className="flex gap-6">
              <Link href="/">
                <a className="hover:text-primary transition-colors" data-testid="link-calculator">Calculator</a>
              </Link>
              <Link href="/blog">
                <a className="hover:text-primary transition-colors" data-testid="link-blog">Blog</a>
              </Link>
              <Link href="/about">
                <a className="hover:text-primary transition-colors" data-testid="link-about">About</a>
              </Link>
              <Link href="/contact">
                <a className="text-primary font-semibold" data-testid="link-contact">Contact</a>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="bg-gradient-to-br from-primary/10 to-primary/5 py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Get in Touch</h1>
          <p className="text-xl text-muted-foreground">
            Have questions? We're here to help you understand your salary calculations
          </p>
        </div>
      </section>

      {/* Contact Content */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div>
              <h2 className="text-2xl font-bold mb-6">Send us a Message</h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium mb-2">Your Name</label>
                  <Input
                    type="text"
                    placeholder="John Doe"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                    data-testid="input-name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Email Address</label>
                  <Input
                    type="email"
                    placeholder="john@example.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                    data-testid="input-email"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Subject</label>
                  <Input
                    type="text"
                    placeholder="How can we help?"
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    required
                    data-testid="input-subject"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Message</label>
                  <Textarea
                    placeholder="Tell us more about your question or feedback..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    required
                    rows={6}
                    data-testid="input-message"
                  />
                </div>
                <Button type="submit" className="w-full gradient-bg text-white" data-testid="button-submit">
                  Send Message
                </Button>
              </form>
            </div>

            {/* Contact Info */}
            <div className="space-y-8">
              <div>
                <h2 className="text-2xl font-bold mb-6">Contact Information</h2>
                <div className="space-y-6">
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <Mail className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                        <div>
                          <h3 className="font-semibold mb-1">Email Us</h3>
                          <p className="text-muted-foreground mb-2">
                            For general inquiries and support
                          </p>
                          <a href="mailto:support@salarytax.org" className="text-primary hover:underline">
                            support@salarytax.org
                          </a>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <MessageSquare className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                        <div>
                          <h3 className="font-semibold mb-1">Live Chat</h3>
                          <p className="text-muted-foreground mb-2">
                            Chat with our team in real-time
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Available Monday-Friday, 9am-5pm EST
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <Clock className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                        <div>
                          <h3 className="font-semibold mb-1">Response Time</h3>
                          <p className="text-muted-foreground mb-2">
                            We typically respond within 24 hours
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Priority support available for HR SaaS subscribers
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <MapPin className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                        <div>
                          <h3 className="font-semibold mb-1">Global Team</h3>
                          <p className="text-muted-foreground">
                            Our team operates across multiple time zones to provide support worldwide
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>

              <div className="bg-muted/50 p-6 rounded-lg">
                <h3 className="font-semibold mb-3">Quick Links</h3>
                <div className="space-y-2">
                  <Link href="/faq">
                    <a className="block text-primary hover:underline" data-testid="link-faq">
                      Frequently Asked Questions →
                    </a>
                  </Link>
                  <Link href="/blog">
                    <a className="block text-primary hover:underline" data-testid="link-blog-cta">
                      Read Our Blog →
                    </a>
                  </Link>
                  <Link href="/tax-guides">
                    <a className="block text-primary hover:underline" data-testid="link-tax-guides">
                      Tax Calculation Guides →
                    </a>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Business Inquiries */}
      <section className="bg-muted/30 py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Business & Enterprise Inquiries</h2>
          <p className="text-lg text-muted-foreground mb-8">
            Looking for HR SaaS solutions or custom integrations for your organization?
          </p>
          <a href="mailto:enterprise@salarytax.org">
            <Button size="lg" className="gradient-bg text-white" data-testid="button-enterprise">
              Contact Enterprise Sales
            </Button>
          </a>
        </div>
      </section>
    </div>
  );
}
