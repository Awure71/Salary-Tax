import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Globe, Calculator, FileText, TrendingUp } from "lucide-react";
import { AdSenseScript } from "@/components/adsense";

export default function TaxGuides() {
  return (
    <div className="min-h-screen bg-background">
      <AdSenseScript />
      {/* Header */}
      <header className="border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <a className="text-2xl font-bold gradient-text" data-testid="link-home">SalaryTax</a>
            </Link>
            <nav className="flex gap-6">
              <Link href="/">
                <a className="hover:text-primary transition-colors" data-testid="link-calculator">Calculator</a>
              </Link>
              <Link href="/blog">
                <a className="hover:text-primary transition-colors" data-testid="link-blog">Blog</a>
              </Link>
              <Link href="/about">
                <a className="hover:text-primary transition-colors" data-testid="link-about">About</a>
              </Link>
            </nav>
          </div>
        </div>
      </header>
      <TaxGuidesContent />
    </div>
  );
}

function TaxGuidesContent() {
  const guides = [
    {
      country: "United States",
      flag: "🇺🇸",
      description: "Federal and state income tax, Social Security, Medicare, and state-specific deductions",
      highlights: ["7 federal tax brackets (10%-37%)", "State taxes vary by location", "FICA taxes: 7.65%"]
    },
    {
      country: "United Kingdom",
      flag: "🇬🇧",
      description: "Income tax, National Insurance, and pension contributions for UK employees",
      highlights: ["Personal Allowance: £12,570", "Basic rate: 20%", "Higher rate: 40%", "Additional rate: 45%"]
    },
    {
      country: "Canada",
      flag: "🇨🇦",
      description: "Federal and provincial taxes, CPP, EI, and RRSP contributions",
      highlights: ["Federal rates: 15%-33%", "Provincial taxes additional", "CPP: 5.95%"]
    },
    {
      country: "Germany",
      flag: "🇩🇪",
      description: "Income tax, solidarity surcharge, church tax, and social insurance contributions",
      highlights: ["Progressive rates: 0%-45%", "Solidarity surcharge: 5.5%", "Social insurance: ~20%"]
    },
    {
      country: "Australia",
      flag: "🇦🇺",
      description: "Income tax, Medicare levy, and superannuation contributions",
      highlights: ["Tax-free threshold: $18,200", "Medicare levy: 2%", "Super: 11%"]
    },
    {
      country: "France",
      flag: "🇫🇷",
      description: "Income tax, social charges, and retirement contributions",
      highlights: ["Progressive rates: 0%-45%", "Social charges: ~22%", "CSG: 9.2%"]
    }
  ];

  return (
    <>
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary/10 to-primary/5 py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Global Tax Calculation Guides</h1>
          <p className="text-xl text-muted-foreground">
            Comprehensive guides to understanding tax systems in 25+ countries worldwide
          </p>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="prose prose-lg max-w-none mb-12">
            <p className="text-lg text-muted-foreground mb-4">
              Understanding how taxes are calculated in different countries is essential for financial planning, whether you're considering a job offer abroad, relocating for work, or managing international payroll. Each country has unique tax systems with varying rates, brackets, deductions, and social contributions.
            </p>
            <p className="text-lg text-muted-foreground">
              Our comprehensive tax guides break down the complexities of each country's tax system, helping you understand exactly how your gross salary translates to take-home pay. From progressive tax brackets to mandatory social insurance contributions, we cover everything you need to know.
            </p>
          </div>

          {/* Features */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            <Card className="text-center">
              <CardContent className="pt-6">
                <Globe className="h-10 w-10 mx-auto mb-3 text-primary" />
                <h3 className="font-semibold mb-2">25+ Countries</h3>
                <p className="text-sm text-muted-foreground">Comprehensive coverage worldwide</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="pt-6">
                <Calculator className="h-10 w-10 mx-auto mb-3 text-primary" />
                <h3 className="font-semibold mb-2">Real-Time Updates</h3>
                <p className="text-sm text-muted-foreground">Tax rates updated within 24 hours</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="pt-6">
                <FileText className="h-10 w-10 mx-auto mb-3 text-primary" />
                <h3 className="font-semibold mb-2">Detailed Breakdowns</h3>
                <p className="text-sm text-muted-foreground">Every deduction explained</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="pt-6">
                <TrendingUp className="h-10 w-10 mx-auto mb-3 text-primary" />
                <h3 className="font-semibold mb-2">Historical Data</h3>
                <p className="text-sm text-muted-foreground">Compare rates over time</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Country Guides */}
      <section className="bg-muted/30 py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Country-Specific Tax Guides</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {guides.map((guide, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow" data-testid={`card-guide-${index}`}>
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-4xl">{guide.flag}</span>
                    <CardTitle className="text-xl">{guide.country}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">{guide.description}</p>
                  <div className="space-y-2 mb-4">
                    <p className="text-sm font-semibold">Key Points:</p>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      {guide.highlights.map((highlight, i) => (
                        <li key={i} className="flex items-start">
                          <span className="text-primary mr-2">•</span>
                          {highlight}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <Link href={`/?country=${guide.country.toLowerCase().replace(' ', '-')}`}>
                    <Button variant="outline" className="w-full" data-testid={`button-calculate-${index}`}>
                      Calculate for {guide.country}
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Tax Concepts */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Understanding Key Tax Concepts</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Progressive Tax Brackets</CardTitle>
              </CardHeader>
              <CardContent className="text-muted-foreground">
                <p className="mb-3">
                  Most countries use progressive tax systems where income is divided into brackets, each taxed at a different rate. Only the income within each bracket is taxed at that rate—not your entire salary.
                </p>
                <p className="mb-3">
                  For example, if you earn $60,000 with brackets of 10% (up to $10k), 20% ($10k-$40k), and 30% (over $40k):
                </p>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>First $10,000 at 10% = $1,000</li>
                  <li>Next $30,000 at 20% = $6,000</li>
                  <li>Final $20,000 at 30% = $6,000</li>
                  <li><strong>Total tax: $13,000 (21.7% effective rate)</strong></li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Social Security Contributions</CardTitle>
              </CardHeader>
              <CardContent className="text-muted-foreground">
                <p className="mb-3">
                  Beyond income tax, most countries require contributions to social security programs covering retirement, healthcare, unemployment, and disability insurance.
                </p>
                <p className="mb-3">
                  These contributions are typically split between employer and employee:
                </p>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Employee pays a percentage of gross salary</li>
                  <li>Employer pays an additional percentage</li>
                  <li>Combined, these fund public benefit programs</li>
                  <li>Rates vary significantly by country (5%-25%)</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Tax Deductions & Allowances</CardTitle>
              </CardHeader>
              <CardContent className="text-muted-foreground">
                <p className="mb-3">
                  Tax deductions reduce your taxable income, lowering the amount of income subject to tax. Common deductions include:
                </p>
                <ul className="list-disc list-inside space-y-1 text-sm mb-3">
                  <li>Personal allowance (tax-free income)</li>
                  <li>Retirement/pension contributions</li>
                  <li>Charitable donations</li>
                  <li>Mortgage interest (in some countries)</li>
                  <li>Business expenses (self-employed)</li>
                  <li>Education expenses</li>
                </ul>
                <p className="text-sm">
                  Maximizing legitimate deductions can significantly reduce your tax burden.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Regional & Local Taxes</CardTitle>
              </CardHeader>
              <CardContent className="text-muted-foreground">
                <p className="mb-3">
                  Many countries have additional taxes at state, provincial, or local levels:
                </p>
                <ul className="list-disc list-inside space-y-1 text-sm mb-3">
                  <li><strong>United States:</strong> State income tax (0%-13.3%)</li>
                  <li><strong>Canada:</strong> Provincial tax (varies by province)</li>
                  <li><strong>Germany:</strong> Church tax (if applicable)</li>
                  <li><strong>Switzerland:</strong> Canton and municipal taxes</li>
                </ul>
                <p className="text-sm">
                  Our calculator accounts for all applicable regional taxes based on your location.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gradient-to-br from-primary/10 to-primary/5 py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Calculate Your Take-Home Pay?</h2>
          <p className="text-xl text-muted-foreground mb-8">
            Use our calculator to get accurate salary breakdowns for any country
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/">
              <Button size="lg" className="gradient-bg text-white" data-testid="button-calculator">
                Try Calculator Now
              </Button>
            </Link>
            <Link href="/blog">
              <Button size="lg" variant="outline" data-testid="button-blog">
                Read Tax Articles
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
