import { CalculationResult } from "@/pages/home";

interface TaxCalculationInput {
  grossSalary: number;
  employmentType: string;
  state: string;
  includePension: boolean;
  includeNHF: boolean;
}

// Legacy tax bands - kept for backward compatibility
const TAX_BANDS = [
  { min: 0, max: 300000, rate: 0.07 },
  { min: 300000, max: 600000, rate: 0.11 },
  { min: 600000, max: 1100000, rate: 0.15 },
  { min: 1100000, max: 1600000, rate: 0.19 },
  { min: 1600000, max: Infinity, rate: 0.24 }
];

export function calculatePAYE(annualSalary: number): number {
  let totalTax = 0;
  let remainingSalary = annualSalary;

  for (const band of TAX_BANDS) {
    if (remainingSalary <= 0) break;
    
    const taxableInBand = Math.min(remainingSalary, band.max - band.min);
    totalTax += taxableInBand * band.rate;
    remainingSalary -= taxableInBand;
  }

  return Math.round(totalTax / 12); // Monthly PAYE
}

// Legacy function - use calculateGlobalTax for new implementations
// This function is deprecated and maintained only for backward compatibility
export function calculateNigerianTax(input: TaxCalculationInput): any {
  const { grossSalary, employmentType, state, includePension, includeNHF } = input;
  
  const annualSalary = grossSalary * 12;
  const payeTax = calculatePAYE(annualSalary);
  const pensionDeduction = includePension ? Math.round(grossSalary * 0.08) : 0;
  const nhfDeduction = includeNHF ? Math.round(grossSalary * 0.025) : 0;
  const totalDeductions = payeTax + pensionDeduction + nhfDeduction;
  const netPay = grossSalary - totalDeductions;
  
  return {
    countryCode: 'NG',
    currency: 'NGN',
    currencySymbol: '$',
    grossSalary,
    incomeTax: payeTax,
    deductions: [
      ...(includePension ? [{ id: 'pension', name: 'Pension Contribution', amount: pensionDeduction, rate: 0.08 }] : []),
      ...(includeNHF ? [{ id: 'nhf', name: 'National Housing Fund', amount: nhfDeduction, rate: 0.025 }] : [])
    ],
    totalDeductions: pensionDeduction + nhfDeduction,
    netPay,
    employmentType,
    state,
    taxBandBreakdown: []
  };
}

export function formatCurrency(amount: number, symbol: string = '$'): string {
  return `${symbol}${amount.toLocaleString()}`;
}

export function getTaxBandInfo(currencySymbol: string = '$') {
  return TAX_BANDS.map(band => ({
    range: band.max === Infinity 
      ? `Above ${currencySymbol}${band.min.toLocaleString()}`
      : `${currencySymbol}${band.min.toLocaleString()} - ${currencySymbol}${band.max.toLocaleString()}`,
    rate: `${(band.rate * 100).toFixed(0)}%`
  }));
}
