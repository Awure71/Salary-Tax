// Global countries configuration for tax calculations
export interface TaxBand {
  min: number;
  max: number;
  rate: number;
}

export interface DeductionType {
  id: string;
  name: string;
  rate: number;
  description: string;
  isDefault: boolean;
  maxAmount?: number; // Optional cap on deduction
}

export interface CountryConfig {
  code: string;
  name: string;
  currency: {
    code: string;
    symbol: string;
    name: string;
  };
  taxBands: TaxBand[];
  deductions: DeductionType[];
  taxFrequency: 'monthly' | 'annual'; // How tax is calculated
  states?: string[]; // Optional states/regions
}

export const COUNTRIES_CONFIG: Record<string, CountryConfig> = {
  NG: {
    code: 'NG',
    name: 'Nigeria',
    currency: {
      code: 'NGN',
      symbol: '₦',
      name: 'Nigerian Naira'
    },
    taxBands: [
      { min: 0, max: 300000, rate: 0.07 },        // First ₦300,000 - 7%
      { min: 300000, max: 600000, rate: 0.11 },   // Next ₦300,000 - 11%
      { min: 600000, max: 1100000, rate: 0.15 },  // Next ₦500,000 - 15%
      { min: 1100000, max: 1600000, rate: 0.19 }, // Next ₦500,000 - 19%
      { min: 1600000, max: Infinity, rate: 0.24 } // Above ₦1,600,000 - 24%
    ],
    deductions: [
      {
        id: 'pension',
        name: 'Pension Contribution',
        rate: 0.08,
        description: 'Employee pension contribution (8%)',
        isDefault: true
      },
      {
        id: 'nhf',
        name: 'National Housing Fund',
        rate: 0.025,
        description: 'NHF contribution (2.5%)',
        isDefault: false
      }
    ],
    taxFrequency: 'annual',
    states: ['Lagos', 'Abuja (FCT)', 'Rivers', 'Kano', 'Other']
  },

  US: {
    code: 'US',
    name: 'United States',
    currency: {
      code: 'USD',
      symbol: '$',
      name: 'US Dollar'
    },
    taxBands: [
      { min: 0, max: 11000, rate: 0.10 },         // 10%
      { min: 11000, max: 44725, rate: 0.12 },     // 12%
      { min: 44725, max: 95375, rate: 0.22 },     // 22%
      { min: 95375, max: 182050, rate: 0.24 },    // 24%
      { min: 182050, max: 231250, rate: 0.32 },   // 32%
      { min: 231250, max: 578125, rate: 0.35 },   // 35%
      { min: 578125, max: Infinity, rate: 0.37 }  // 37%
    ],
    deductions: [
      {
        id: 'social_security',
        name: 'Social Security',
        rate: 0.062,
        description: 'Social Security tax (6.2%)',
        isDefault: true,
        maxAmount: 160200 * 0.062 // 2024 wage base limit
      },
      {
        id: 'medicare',
        name: 'Medicare',
        rate: 0.0145,
        description: 'Medicare tax (1.45%)',
        isDefault: true
      },
      {
        id: '401k',
        name: '401(k) Contribution',
        rate: 0.10,
        description: 'Pre-tax retirement savings (10%)',
        isDefault: false
      }
    ],
    taxFrequency: 'annual',
    states: ['California', 'New York', 'Texas', 'Florida', 'Other']
  },

  GB: {
    code: 'GB',
    name: 'United Kingdom',
    currency: {
      code: 'GBP',
      symbol: '£',
      name: 'British Pound'
    },
    taxBands: [
      { min: 0, max: 12570, rate: 0.00 },         // Personal allowance - 0%
      { min: 12570, max: 50270, rate: 0.20 },     // Basic rate - 20%
      { min: 50270, max: 125140, rate: 0.40 },    // Higher rate - 40%
      { min: 125140, max: Infinity, rate: 0.45 }  // Additional rate - 45%
    ],
    deductions: [
      {
        id: 'ni_employee',
        name: 'National Insurance',
        rate: 0.12,
        description: 'Employee National Insurance (12%)',
        isDefault: true
      },
      {
        id: 'pension_uk',
        name: 'Workplace Pension',
        rate: 0.05,
        description: 'Auto-enrolment pension (5%)',
        isDefault: true
      }
    ],
    taxFrequency: 'annual'
  },

  CA: {
    code: 'CA',
    name: 'Canada',
    currency: {
      code: 'CAD',
      symbol: 'C$',
      name: 'Canadian Dollar'
    },
    taxBands: [
      { min: 0, max: 53359, rate: 0.15 },         // 15%
      { min: 53359, max: 106717, rate: 0.205 },   // 20.5%
      { min: 106717, max: 165430, rate: 0.26 },   // 26%
      { min: 165430, max: 235675, rate: 0.29 },   // 29%
      { min: 235675, max: Infinity, rate: 0.33 }  // 33%
    ],
    deductions: [
      {
        id: 'cpp',
        name: 'Canada Pension Plan',
        rate: 0.0595,
        description: 'CPP contribution (5.95%)',
        isDefault: true,
        maxAmount: 71300 * 0.0595 // 2024 maximum pensionable earnings
      },
      {
        id: 'ei',
        name: 'Employment Insurance',
        rate: 0.0229,
        description: 'EI premium (2.29%)',
        isDefault: true,
        maxAmount: 63300 * 0.0229 // 2024 maximum insurable earnings
      }
    ],
    taxFrequency: 'annual',
    states: ['Ontario', 'Quebec', 'British Columbia', 'Alberta', 'Other']
  },

  AU: {
    code: 'AU',
    name: 'Australia',
    currency: {
      code: 'AUD',
      symbol: 'A$',
      name: 'Australian Dollar'
    },
    taxBands: [
      { min: 0, max: 18200, rate: 0.00 },         // Tax-free threshold - 0%
      { min: 18200, max: 45000, rate: 0.19 },     // 19%
      { min: 45000, max: 120000, rate: 0.325 },   // 32.5%
      { min: 120000, max: 180000, rate: 0.37 },   // 37%
      { min: 180000, max: Infinity, rate: 0.45 }  // 45%
    ],
    deductions: [
      {
        id: 'superannuation',
        name: 'Superannuation',
        rate: 0.115,
        description: 'Superannuation guarantee (11.5%)',
        isDefault: true
      },
      {
        id: 'medicare_levy',
        name: 'Medicare Levy',
        rate: 0.02,
        description: 'Medicare levy (2%)',
        isDefault: true
      }
    ],
    taxFrequency: 'annual',
    states: ['New South Wales', 'Victoria', 'Queensland', 'Western Australia', 'Other']
  },

  ZA: {
    code: 'ZA',
    name: 'South Africa',
    currency: {
      code: 'ZAR',
      symbol: 'R',
      name: 'South African Rand'
    },
    taxBands: [
      { min: 0, max: 237100, rate: 0.18 },        // 18%
      { min: 237100, max: 370500, rate: 0.26 },   // 26%
      { min: 370500, max: 512800, rate: 0.31 },   // 31%
      { min: 512800, max: 673000, rate: 0.36 },   // 36%
      { min: 673000, max: 857900, rate: 0.39 },   // 39%
      { min: 857900, max: 1817000, rate: 0.41 },  // 41%
      { min: 1817000, max: Infinity, rate: 0.45 } // 45%
    ],
    deductions: [
      {
        id: 'uif',
        name: 'Unemployment Insurance Fund',
        rate: 0.01,
        description: 'UIF contribution (1%)',
        isDefault: true,
        maxAmount: 177120 * 0.01 // 2024 UIF ceiling
      },
      {
        id: 'pension_za',
        name: 'Pension Fund',
        rate: 0.075,
        description: 'Pension fund contribution (7.5%)',
        isDefault: false
      }
    ],
    taxFrequency: 'annual',
    states: ['Gauteng', 'Western Cape', 'KwaZulu-Natal', 'Eastern Cape', 'Other']
  }
};

export function getCountry(countryCode: string): CountryConfig | undefined {
  return COUNTRIES_CONFIG[countryCode];
}

export function getAllCountries(): CountryConfig[] {
  return Object.values(COUNTRIES_CONFIG);
}

export function formatCurrency(amount: number, countryCode: string): string {
  const country = getCountry(countryCode);
  if (!country) return amount.toLocaleString();
  
  return `${country.currency.symbol}${amount.toLocaleString()}`;
}

export function getEmploymentTypes(): string[] {
  return [
    'full-time',
    'part-time',
    'contract',
    'freelance',
    'self-employed',
    'intern'
  ];
}