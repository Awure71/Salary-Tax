import { getCountry, CountryConfig, DeductionType } from './countries-config';

export interface GlobalTaxInput {
  countryCode: string;
  grossSalary: number;
  employmentType: string;
  state?: string;
  selectedDeductions: string[]; // Array of deduction IDs
}

export interface GlobalCalculationResult {
  countryCode: string;
  currency: string;
  currencySymbol: string;
  grossSalary: number;
  incomeTax: number;
  deductions: Array<{
    id: string;
    name: string;
    amount: number;
    rate: number;
  }>;
  totalDeductions: number;
  netPay: number;
  employmentType: string;
  state?: string;
  taxBandBreakdown: Array<{
    range: string;
    rate: string;
    taxableAmount: number;
    taxAmount: number;
  }>;
}

export function calculateIncomeTax(annualSalary: number, country: CountryConfig): { tax: number, breakdown: Array<any> } {
  let totalTax = 0;
  let remainingSalary = annualSalary;
  const breakdown = [];

  for (const band of country.taxBands) {
    if (remainingSalary <= 0) break;
    
    const taxableInBand = Math.min(remainingSalary, band.max - band.min);
    const taxInBand = taxableInBand * band.rate;
    totalTax += taxInBand;
    
    breakdown.push({
      range: band.max === Infinity 
        ? `Above ${country.currency.symbol}${band.min.toLocaleString()}`
        : `${country.currency.symbol}${band.min.toLocaleString()} - ${country.currency.symbol}${band.max.toLocaleString()}`,
      rate: `${(band.rate * 100).toFixed(1)}%`,
      taxableAmount: taxableInBand,
      taxAmount: taxInBand
    });
    
    remainingSalary -= taxableInBand;
  }

  return {
    tax: country.taxFrequency === 'annual' ? Math.round(totalTax / 12) : Math.round(totalTax),
    breakdown
  };
}

export function calculateDeduction(
  grossSalary: number, 
  deduction: DeductionType, 
  annualSalary: number
): number {
  let deductionAmount = grossSalary * deduction.rate;
  
  // Apply maximum cap if specified (usually for annual calculations)
  if (deduction.maxAmount) {
    const annualDeduction = annualSalary * deduction.rate;
    if (annualDeduction > deduction.maxAmount) {
      deductionAmount = deduction.maxAmount / 12; // Convert back to monthly
    }
  }
  
  return Math.round(deductionAmount);
}

export function calculateGlobalTax(input: GlobalTaxInput): GlobalCalculationResult {
  const { countryCode, grossSalary, employmentType, state, selectedDeductions } = input;
  
  const country = getCountry(countryCode);
  if (!country) {
    throw new Error(`Country ${countryCode} not supported`);
  }
  
  // Calculate annual salary for tax calculation
  const annualSalary = grossSalary * 12;
  
  // Calculate income tax
  const { tax: incomeTax, breakdown: taxBandBreakdown } = calculateIncomeTax(annualSalary, country);
  
  // Calculate deductions
  const deductionResults = [];
  let totalDeductionAmount = 0;
  
  for (const deductionId of selectedDeductions) {
    const deduction = country.deductions.find(d => d.id === deductionId);
    if (deduction) {
      const amount = calculateDeduction(grossSalary, deduction, annualSalary);
      deductionResults.push({
        id: deduction.id,
        name: deduction.name,
        amount,
        rate: deduction.rate
      });
      totalDeductionAmount += amount;
    }
  }
  
  // Calculate total deductions including income tax
  const totalDeductions = incomeTax + totalDeductionAmount;
  
  // Calculate net pay
  const netPay = grossSalary - totalDeductions;
  
  return {
    countryCode,
    currency: country.currency.code,
    currencySymbol: country.currency.symbol,
    grossSalary,
    incomeTax,
    deductions: deductionResults,
    totalDeductions: totalDeductionAmount,
    netPay,
    employmentType,
    state,
    taxBandBreakdown: taxBandBreakdown.filter(band => band.taxableAmount > 0)
  };
}

export function getDefaultDeductions(countryCode: string): string[] {
  const country = getCountry(countryCode);
  if (!country) return [];
  
  return country.deductions
    .filter(deduction => deduction.isDefault)
    .map(deduction => deduction.id);
}