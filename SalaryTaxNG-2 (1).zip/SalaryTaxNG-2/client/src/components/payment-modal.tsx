import { useState } from "react";
import { useLocation } from "wouter";
import { X, CreditCard, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CalculationResult } from "@/pages/home";
import { useToast } from "@/hooks/use-toast";

interface PaymentModalProps {
  calculationResult: CalculationResult | null;
  selectedPlan: 'basic' | 'pdf' | 'saas';
  onClose: () => void;
}

export default function PaymentModal({ calculationResult, selectedPlan, onClose }: PaymentModalProps) {
  const [, setLocation] = useLocation();
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const planDetails = {
    basic: { name: 'Basic Payslip', price: 0.50, description: 'Single calculation with basic payslip preview' },
    pdf: { name: 'Professional PDF Payslip', price: 1.50, description: 'Includes company branding and email delivery' },
    saas: { name: 'HR SaaS Monthly', price: 29.00, description: 'Bulk processing with priority support' }
  };

  const currentPlan = planDetails[selectedPlan];

  const handlePayment = () => {
    if (!calculationResult) {
      toast({
        title: "Error",
        description: "Please calculate your salary first",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    
    // Store calculation data and plan in localStorage for checkout page
    localStorage.setItem('salaryCalculation', JSON.stringify(calculationResult));
    localStorage.setItem('selectedPlan', selectedPlan);
    
    // Navigate to checkout page
    setLocation('/checkout');
  };

  if (!calculationResult) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" data-testid="payment-modal">
      <Card className="max-w-md w-full animate-bounce-in">
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <CardTitle>Purchase PDF Payslip</CardTitle>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onClose}
            data-testid="button-close-modal"
          >
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="bg-muted/50 p-4 rounded-lg">
            <div className="flex justify-between mb-2">
              <span>{currentPlan.name}</span>
              <span className="font-semibold">${currentPlan.price.toFixed(2)}</span>
            </div>
            <div className="text-sm text-muted-foreground">
              {currentPlan.description}
            </div>
          </div>
          
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Your salary calculation will be processed and you'll receive {selectedPlan === 'pdf' ? 'a professional PDF payslip' : selectedPlan === 'basic' ? 'a basic payslip preview' : 'full access to HR SaaS features'}.
            </p>
            
            <div className="text-sm">
              <strong>What you'll get:</strong>
              <ul className="list-disc list-inside mt-2 space-y-1 text-muted-foreground">
                {selectedPlan === 'basic' && (
                  <>
                    <li>Single salary calculation</li>
                    <li>Basic payslip preview</li>
                    <li>Social media sharing</li>
                  </>
                )}
                {selectedPlan === 'pdf' && (
                  <>
                    <li>Professional PDF payslip format</li>
                    <li>Complete salary breakdown</li>
                    <li>Suitable for loan applications</li>
                    <li>Instant email delivery</li>
                  </>
                )}
                {selectedPlan === 'saas' && (
                  <>
                    <li>Unlimited calculations</li>
                    <li>Bulk payslip processing</li>
                    <li>Priority support</li>
                    <li>Advanced reporting</li>
                  </>
                )}
              </ul>
            </div>
          </div>
          
          <Button 
            onClick={handlePayment}
            className="w-full gradient-bg text-white font-semibold"
            disabled={isProcessing}
            data-testid="button-proceed-payment"
          >
            {isProcessing ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <CreditCard className="h-4 w-4 mr-2" />
                Pay ${currentPlan.price.toFixed(2)} - Proceed to Checkout
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
