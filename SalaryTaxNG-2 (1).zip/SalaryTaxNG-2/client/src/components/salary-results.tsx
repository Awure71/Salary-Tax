import { Download, Share2, Copy, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { CalculationResult } from "@/pages/home";
import { useToast } from "@/hooks/use-toast";

interface SalaryResultsProps {
  result: CalculationResult;
  onDownloadPdf: () => void;
}

export default function SalaryResults({ result, onDownloadPdf }: SalaryResultsProps) {
  const { toast } = useToast();

  const takeHomePercentage = ((result.netPay / result.grossSalary) * 100).toFixed(1);

  const shareToTwitter = () => {
    const text = `I calculated my salary: ${result.currencySymbol}${result.grossSalary.toLocaleString()} gross = ${result.currencySymbol}${result.netPay.toLocaleString()} take-home. Calculate yours at`;
    const url = window.location.origin;
    
    window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`, '_blank');
  };

  const shareToWhatsApp = () => {
    const text = `How much do you really take home? 🤔\n\nI calculated mine: ${result.currencySymbol}${result.grossSalary.toLocaleString()} gross = ${result.currencySymbol}${result.netPay.toLocaleString()} take-home.\n\nCalculate yours: ${window.location.origin}`;
    
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const copyResults = async () => {
    const deductionsText = result.deductions.map(d => `${d.name}: ${result.currencySymbol}${d.amount.toLocaleString()}`).join('\n');
    const text = `Salary Breakdown:\nGross: ${result.currencySymbol}${result.grossSalary.toLocaleString()}\nIncome Tax: ${result.currencySymbol}${result.incomeTax.toLocaleString()}\n${deductionsText}\nNet Pay: ${result.currencySymbol}${result.netPay.toLocaleString()}\n\nCalculated at: ${window.location.origin}`;
    
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: "Results copied to clipboard successfully.",
      });
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy to clipboard. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="mt-8 animate-slide-up" data-testid="salary-results">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-6">
        <CardTitle className="text-xl">Your Salary Breakdown</CardTitle>
        <Button 
          onClick={onDownloadPdf} 
          className="bg-accent text-accent-foreground hover:bg-accent/90"
          data-testid="button-download-pdf"
        >
          <Download className="h-4 w-4 mr-2" />
          Download PDF ($1.50)
        </Button>
      </CardHeader>
      
      <CardContent className="space-y-6">
        <div className="grid md:grid-cols-2 gap-6">
          {/* Summary Card */}
          <Card className="gradient-bg text-white">
            <CardContent className="p-6">
              <h4 className="text-lg font-semibold mb-4">Take-Home Pay</h4>
              <div className="text-3xl font-bold mb-2" data-testid="text-take-home-pay">
                {result.currencySymbol}{result.netPay.toLocaleString()}
              </div>
              <div className="text-sm opacity-90" data-testid="text-take-home-percentage">
                {takeHomePercentage}% of gross salary
              </div>
            </CardContent>
          </Card>
          
          {/* Breakdown */}
          <div className="space-y-4">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Gross Salary:</span>
              <span className="font-semibold" data-testid="text-gross-salary">
                {result.currencySymbol}{result.grossSalary.toLocaleString()}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Income Tax:</span>
              <span className="font-semibold text-destructive" data-testid="text-income-tax">
                -{result.currencySymbol}{result.incomeTax.toLocaleString()}
              </span>
            </div>
            {result.deductions.map((deduction) => (
              <div key={deduction.id} className="flex justify-between">
                <span className="text-muted-foreground">{deduction.name} ({(deduction.rate * 100).toFixed(1)}%):</span>
                <span className="font-semibold text-destructive" data-testid={`text-${deduction.id}`}>
                  -{result.currencySymbol}{deduction.amount.toLocaleString()}
                </span>
              </div>
            ))}
            <Separator />
            <div className="flex justify-between text-lg font-bold">
              <span>Net Pay:</span>
              <span data-testid="text-net-pay">{result.currencySymbol}{result.netPay.toLocaleString()}</span>
            </div>
          </div>
        </div>
        
        {/* Share Results */}
        <div className="pt-6 border-t border-border">
          <h4 className="font-semibold mb-3">Share Your Results</h4>
          <div className="flex gap-3">
            <Button 
              onClick={shareToTwitter} 
              className="flex-1 bg-blue-500 text-white hover:bg-blue-600"
              data-testid="button-share-twitter"
            >
              <Share2 className="h-4 w-4 mr-2" />
              Twitter
            </Button>
            <Button 
              onClick={shareToWhatsApp} 
              className="flex-1 bg-green-500 text-white hover:bg-green-600"
              data-testid="button-share-whatsapp"
            >
              <MessageCircle className="h-4 w-4 mr-2" />
              WhatsApp
            </Button>
            <Button 
              onClick={copyResults} 
              variant="secondary" 
              className="flex-1"
              data-testid="button-copy-results"
            >
              <Copy className="h-4 w-4 mr-2" />
              Copy
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
